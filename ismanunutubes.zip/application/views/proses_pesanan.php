<div class="container-fluid">
    <div class="alert alert-primary">
        <p class="text-center alifn-middle ">Terimah Kasih Telah Mengunjungi Website Kami.<br>Pesanan Anda Sedang Di Proses</p>
    </div>
    <div align="center">
        <a href="<?php echo base_url('dashboard/hapus_keranjang')?>"><div class="btn btn-sm btn-danger ">Kembali ke Dashboard</div></a>
    </div>
</div>